package presentation.control;

import context.SessionManager;
import domain.entities.Employee;
import domain.entities.Role;
import domain.entities.store.Branch;
import domain.services.DataService;
import domain.services.EmployeeService;
import domain.services.ShiftService;
import domain.services.StoreDetailsService;
import presentation.model.BranchPL;
import presentation.model.StoreDetailsPL;
import shared.enums.JobScope;
import shared.enums.SalaryType;
import shared.enums.WeekDay;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class CreateStoreController {
    private final EmployeeService employeeService;
    private final ShiftService shiftService;
    private final DataService dataService;
    private final StoreDetailsService storeDetailsService;

    public CreateStoreController() {
        this.storeDetailsService = new StoreDetailsService();
        employeeService = new EmployeeService();
        shiftService = new ShiftService();
        dataService = new DataService();
    }

    public String registerManager(String id, String name, String bankAccount, String weekDay) {
        List<Role> roles = new ArrayList<>();
        roles.add(Role.MANAGER);
        return employeeService.addEmployee(new Employee(
                id, name, bankAccount, 0, SalaryType.GLOBALLY,
                SessionManager.now(), JobScope.FULL_TIME,
                roles, "", 24, WeekDay.valueOf(weekDay),
                false, new HashMap<>(), true, Branch.ALL_BRANCHES
        ));
    }

    public void setClosedDays(List<WeekDay> closeDays) {
        List<String> closed = new ArrayList<>();
        closeDays.forEach(w -> closed.add(w.name()));
        storeDetailsService.setClosedDays(closed);
    }

    public void load() {
        dataService.load();
    }

    public void setStoreDetails(StoreDetailsPL storeDetailsPL) {
        storeDetailsService.addUpdateStoreDetails(storeDetailsPL);
    }

    public void addBranch(BranchPL branchPL) {
        storeDetailsService.addUpdateBranch(branchPL.toBranch());
    }

    public boolean containsBranch(String location) {
        return storeDetailsService.containsBranchAtLocation(location);
    }

}
